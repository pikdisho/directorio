'''
consigna '''

print("Bienvenido al ejercicio 3!")

numero=float(input("Ingrese el numero a restar: "))

porcentaje = numero * 0.15
print(numero-porcentaje)