'''
msj = 'hola como andamos'

print (msj)

nombre = 'Franco'
mensaje = 'Hola ' + nombre + ' como estamos'

print (mensaje)
print (f"Hola {nombre} como estas") #concatenar
'''



nombrepersonalizado = input("Ingresa tu nombre: ")
print (f"Hola {nombrepersonalizado} como estas")


