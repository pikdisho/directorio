'''

Esta es una nota grandota

'''

print("hola mundo")
edad=25
nombre='franco'
switch = True







print(type(edad)) #para saber el tipo de variable
print(type(nombre))
print(type(switch))

edad1=int('25') #se pone int, str, etc para convertir el dato entre parentesis al tipo de dato deseado
edad2=int('50')
print(edad1+edad2)

print (edad1 == edad2) #comparadores

#python reconoce variables con o sin mayusculas





