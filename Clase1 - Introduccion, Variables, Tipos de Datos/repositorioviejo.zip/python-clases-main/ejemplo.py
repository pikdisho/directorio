print ( "Sea bienvenido usted al programa que muestra datos de usted que obviamente no sabe!!!!!!!!!!")

nombre = input("Introduzca su nombre por favorcito: ")
apellido = input ("ahora su apellido: ")
edad = input ("su edad: ")
dni = input ("finalmente su dni (no le vamos a robar su identidad): ")

print ("Hola tu nombre es " + nombre + " " + apellido + ", tenes " + edad + " y tu dni es " + dni)

